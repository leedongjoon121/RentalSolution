package com.woongjin.util.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class SpringException {
    @ExceptionHandler(Exception.class)
    public ModelAndView allException(Exception e) {
    	ModelAndView modelAndView = new ModelAndView("error/allException");
    	modelAndView.addObject("error", e.getClass().getSimpleName());
    	modelAndView.addObject("message", e.getMessage());
    	return modelAndView;
    }
    
    @ExceptionHandler(GenericException.class)
    public ModelAndView genericException(GenericException e) {
    	ModelAndView modelAndView = new ModelAndView("error/genericException");
    	modelAndView.addObject("error", e.getClass().getSimpleName());
    	modelAndView.addObject("message", e.getExceptionCode()+" - "+e.getExceptionMsg());
    	return modelAndView;
    }
    
    @ExceptionHandler(AjaxException.class)
    public @ResponseBody Map<String,Object> ajaxException(AjaxException e) {
    	
    	Map<String,Object> resultMap = new HashMap<String,Object>();
    	resultMap.put("error", e.getClass().getSimpleName());
    	resultMap.put("message", e.getExceptionCode()+" - "+e.getExceptionMsg());

    	return resultMap;
    }
}
