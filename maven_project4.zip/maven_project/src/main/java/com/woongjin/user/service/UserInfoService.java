package com.woongjin.user.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.woongjin.user.search.UserInfoSearch;
import com.woongjin.user.vo.UserInfoVo;

@Service
public interface UserInfoService {

public List<UserInfoVo> selectList(UserInfoSearch search);

public int selectListCount(UserInfoSearch search);

public UserInfoVo select(String userId);
   
public void insert(UserInfoVo vo);
   
public void update(UserInfoVo vo) throws Exception;
   
public void delete(String userId) throws Exception;
   
}
