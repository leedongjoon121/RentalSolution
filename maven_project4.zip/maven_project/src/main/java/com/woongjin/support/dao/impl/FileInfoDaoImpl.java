package com.woongjin.support.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.support.dao.FileInfoDao;
import com.woongjin.support.vo.FileInfoVo;

@Repository
public class FileInfoDaoImpl implements FileInfoDao{
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "support.Dao.";

	@Override
	public List<FileInfoVo> selectList() {
		// 
		return query.selectList(MAPPER+"selectList");
	}

	@Override
	public int selectListCount() {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectListCount");
	}

	@Override
	public FileInfoVo select(String fileId) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"select",fileId);
	}

	@Override
	public void insert(FileInfoVo vo) {
		query.insert(MAPPER+"insert",vo);
		
	}

	@Override
	public void delete(String fileId) {
		query.delete(MAPPER+"delete",fileId);
		
	}
	

}
