package com.woongjin.user.search;

import com.woongjin.util.Search;

public class UserInfoSearch extends Search{
	 

}
