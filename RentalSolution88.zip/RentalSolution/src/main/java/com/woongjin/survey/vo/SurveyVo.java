package com.woongjin.survey.vo;

import java.util.List;

import com.woongjin.question.vo.QuestionVo;
import com.woongjin.submit.vo.SubmitVo;


public class SurveyVo {

	private String surTitle; // 설문지 제목
	private int surIndex;
	private String surId;
	private String surDate;
	private String surUse;
	
	private List<SubmitVo> submitList;
	
	private List<QuestionVo> questionList;
	
	private List<QuestionVo> questionSubmit;

	public List<QuestionVo> getQuestionSubmit() {
		return questionSubmit;
	}

	public int getSurIndex() {
		return surIndex;
	}

	public void setSurIndex(int surIndex) {
		this.surIndex = surIndex;
	}

	public void setQuestionSubmit(List<QuestionVo> questionSubmit) {
		this.questionSubmit = questionSubmit;
	}

	public List<SubmitVo> getSubmitList() {
		return submitList;
	}

	public void setSubmitList(List<SubmitVo> submitList) {
		this.submitList = submitList;
	}

	public String getSurTitle() {
		return surTitle;
	}

	public void setSurTitle(String surTitle) {
		this.surTitle = surTitle;
	}



	public String getSurId() {
		return surId;
	}

	public void setSurId(String surId) {
		this.surId = surId;
	}

	public String getSurDate() {
		return surDate;
	}

	public void setSurDate(String surDate) {
		this.surDate = surDate;
	}

	public String getSurUse() {
		return surUse;
	}

	public void setSurUse(String surUse) {
		this.surUse = surUse;
	}

	public List<QuestionVo> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<QuestionVo> questionList) {
		this.questionList = questionList;
	}
	
}
