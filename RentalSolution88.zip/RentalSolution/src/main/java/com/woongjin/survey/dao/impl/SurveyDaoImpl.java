package com.woongjin.survey.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.survey.dao.SurveyDao;
import com.woongjin.survey.search.SurveySearch;
import com.woongjin.survey.vo.SurveyVo;

@Repository
public class SurveyDaoImpl implements SurveyDao{
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "surveydao.";

	@Override
	public SurveyVo select(String param1) {
		// TODO Auto-generated method stub
		 return query.selectOne(MAPPER+"select",param1);
	}

	@Override
	public void insert(SurveyVo vo) {
		// TODO Auto-generated method stub
		query.insert(MAPPER+"insert",vo);
	}

	@Override
	public void update(SurveyVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"update",vo);
	}

	@Override
	public void delete(String param1) {
		// TODO Auto-generated method stub
		query.delete(MAPPER+"delete",param1);
	}

	@Override
	public List<SurveyVo> selectList(SurveySearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList", search);
	}

	@Override
	public int selectListCount(SurveySearch search) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectListCount",search);
	}

	 // 사용할 설문지 id 가져오는 것 
	@Override
	public String selUseList(SurveySearch search) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selUseList",search);
	}


}
