package com.woongjin.survey.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.woongjin.survey.search.SurveySearch;
import com.woongjin.survey.vo.SurveyVo;

@Service
public interface SurveyService {
	
	
	public List<SurveyVo> selectList(SurveySearch search); 
	public void insertSV(SurveyVo vo); // 설문지 
	public int selectListCount(SurveySearch search);
	public Map<String,Object> selval(String surId);
	public void insertSM(SurveyVo vo);
	public void update(SurveyVo vo); // 사용 유무 변경 : Y인지 N인지
	public String selUseList(SurveySearch search); // 사용할 설문지의 surId 값 반환   
	   
	  
}
