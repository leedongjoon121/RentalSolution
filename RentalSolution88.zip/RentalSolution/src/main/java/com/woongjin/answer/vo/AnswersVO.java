package com.woongjin.answer.vo;

import java.util.List;

public class AnswersVO {
	List<AnswerVo> answers;
    private String qstId;
    private String aswId;
    
	public String getAswId() {
		return aswId;
	}

	public void setAswId(String aswId) {
		this.aswId = aswId;
	}

	public String getQstId() {
		return qstId;
	}

	public void setQstId(String qstId) {
		this.qstId = qstId;
	}

	public List<AnswerVo> getAnswers() {
		return answers;
	}

	public void setAnswers(List<AnswerVo> answers) {
		this.answers = answers;
	}
}
