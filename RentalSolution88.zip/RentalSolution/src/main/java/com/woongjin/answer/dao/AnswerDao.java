package com.woongjin.answer.dao;

import java.util.List;

import com.woongjin.answer.vo.AnswerVo;
import com.woongjin.survey.search.SurveySearch;

public interface AnswerDao {
	  public AnswerVo select(String param1);
	   
	  public List<AnswerVo> selectList(SurveySearch search); 
	  
	  public List<AnswerVo> selectListval(String surId, String qstId);
	  
	   public void insert(AnswerVo vo);
	   
	   public void update(AnswerVo vo);
	   
	   public void delete(String param1);
}
