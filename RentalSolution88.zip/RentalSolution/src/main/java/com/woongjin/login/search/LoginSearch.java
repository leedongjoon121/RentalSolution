package com.woongjin.login.search;

import com.woongjin.util.Search;

public class LoginSearch extends Search{

}
