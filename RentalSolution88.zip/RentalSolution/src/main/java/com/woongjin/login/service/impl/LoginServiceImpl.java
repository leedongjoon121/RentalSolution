package com.woongjin.login.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.login.dao.LoginDao;
import com.woongjin.login.search.LoginSearch;
import com.woongjin.login.service.LoginService;
import com.woongjin.login.vo.LoginVo;
import com.woongjin.survey.search.SurveySearch;

@Repository
public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginDao logindao;
	
	@Override
	public LoginVo select(String userId) {
		// TODO Auto-generated method stub
		return logindao.select(userId);
	}

	@Override
	public List<LoginVo> selectList(LoginSearch search) {
		// TODO Auto-generated method stub
		 return logindao.selectList(search);
	}

	@Override
	public int selectListCount(SurveySearch search) {
		// TODO Auto-generated method stub
		return logindao.selectListCount(search);
	}

	@Override
	public void insert(LoginVo vo) {
		// TODO Auto-generated method stub
		logindao.insert(vo);
	}

	@Override
	public void update(LoginVo vo) {
		// TODO Auto-generated method stub
		logindao.update(vo);
	}

	@Override
	public void delete(String userId) {
		// TODO Auto-generated method stub
		logindao.delete(userId);
	}

}
