package com.woongjin.login.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.login.dao.LoginDao;
import com.woongjin.login.search.LoginSearch;
import com.woongjin.login.vo.LoginVo;
import com.woongjin.survey.search.SurveySearch;

@Repository
public class LoginDaoImpl implements LoginDao{
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "log.save.";
	
	@Override
	public LoginVo select(String userId) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"select",userId);
	}

	@Override
	public List<LoginVo> selectList(LoginSearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList", search);
	}

	@Override
	public int selectListCount(SurveySearch search) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectListCount",search);
	}

	@Override
	public void insert(LoginVo vo) {
		// TODO Auto-generated method stub
		query.insert(MAPPER+"insert",vo);
	}

	@Override
	public void update(LoginVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"update",vo);
	}

	@Override
	public void delete(String userId) {
		// TODO Auto-generated method stub
		query.delete(MAPPER+"delete",userId);
	}

}
