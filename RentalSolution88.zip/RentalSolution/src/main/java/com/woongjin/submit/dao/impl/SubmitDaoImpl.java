package com.woongjin.submit.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.answer.vo.AnswerVo;
import com.woongjin.submit.dao.SubmitDao;
import com.woongjin.submit.vo.SubmitVo;
import com.woongjin.survey.search.SurveySearch;

@Repository
public class SubmitDaoImpl implements SubmitDao{

	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "submitdao.";
	
	@Override
	public SubmitVo select(String param1) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"select",param1);
	}

	@Override
	public List<SubmitVo> selectList(SurveySearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList", search);
	}

	@Override
	public void insertSM(AnswerVo vo) {
		// TODO Auto-generated method stub
		System.out.println("submitDaoImpl에서 insertSM 호출 됨 !");
		query.insert(MAPPER+"insertSM",vo);
	}

	@Override
	public void update(SubmitVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"update",vo);
	}

	@Override
	public void delete(String param1) {
		// TODO Auto-generated method stub
		query.delete(MAPPER+"delete",param1);
	}

	@Override
	public void insert(SubmitVo vo) {
		// TODO Auto-generated method stub
	
		query.insert(MAPPER+"insert",vo);
	}

}
