package com.woongjin.submit.vo;

import java.util.List;

import com.woongjin.answer.vo.AnswerVo;

public class SubmitsVO {

	List<AnswerVo> answers;

	public List<AnswerVo> getAnswers() {
		return answers;
	}

	public void setAnswers(List<AnswerVo> answers) {
		this.answers = answers;
	}


	
}
