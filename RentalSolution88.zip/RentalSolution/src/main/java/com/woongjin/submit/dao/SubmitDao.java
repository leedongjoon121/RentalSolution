package com.woongjin.submit.dao;

import java.util.List;

import com.woongjin.answer.vo.AnswerVo;
import com.woongjin.submit.vo.SubmitVo;
import com.woongjin.survey.search.SurveySearch;

public interface SubmitDao {
	  public SubmitVo select(String param1);
	   
	  public List<SubmitVo> selectList(SurveySearch search); 
	  
	   public void insertSM(AnswerVo vo); // 설문 결과 인서트
	   
	   public void insert(SubmitVo vo); // 기본 구조 만들때 
	   
	   public void update(SubmitVo vo);
	   
	   public void delete(String param1);
}
