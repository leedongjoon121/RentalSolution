package com.woongjin.submit.vo;

import java.util.List;

import com.woongjin.answer.vo.AnswerVo;

public class SubmitVo {
    public String Id;
    public String surId;
    public String qstId;
    public String aswId;
    public String data;
	
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public String getQstId() {
		return qstId;
	}
	public void setQstId(String qstId) {
		this.qstId = qstId;
	}
	public String getAswId() {
		return aswId;
	}
	public void setAswId(String aswId) {
		this.aswId = aswId;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		String[] tmp = data.split(";");
		this.data = data;
		this.surId = tmp[0];
		this.qstId = tmp[1];
		this.aswId = tmp[2];
	}
	
    
}
