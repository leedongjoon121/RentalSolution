package com.woongjin.support.dao;

public interface SeqInfoDao {
    public long getGuestBookNextId();
}
