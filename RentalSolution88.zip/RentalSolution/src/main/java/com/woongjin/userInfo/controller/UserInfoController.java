package com.woongjin.userInfo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.user.search.UserInfoSearch;
import com.woongjin.user.service.UserInfoService;
import com.woongjin.user.vo.UserInfoVo;


@Controller
public class UserInfoController {
   @Autowired
   private UserInfoService userInfoService;
   

// ------------------------------------------------------------------  
   
   
   @RequestMapping(value="/userInfo/list.do")
   public ModelAndView list(UserInfoSearch search) {
	   
	   search.calculate(userInfoService.selectListCount(search));
	   ModelAndView view = new ModelAndView("userInfo/list");
	   view.addObject("list",userInfoService.selectList(search));
	   view.addObject("search", search);
      return view;
   }
   
   // 이걸로 웹에 json 뿌림 
   @RequestMapping(value="/userInfo/list.json")
   public @ResponseBody Map<String,Object> list2(UserInfoSearch search) {
	   
	   search.calculate(userInfoService.selectListCount(search));
	   Map<String,Object> resultMap = new HashMap<String,Object>();
       resultMap.put("list", userInfoService.selectList(search));
	   return resultMap;
   }
   
   // view는 각 list의 상세 값들 나타내는 것들 임
   @RequestMapping(value="/userInfo/view.do")  
   public ModelAndView view(
		   @RequestParam(value="userId", required=true) String userId,
		   @RequestParam(value="userName", required=false) String userName
		   ) {
	   
	   ModelAndView view = new ModelAndView("userInfo/view");
	   view.addObject("obj",userInfoService.select(userId));
	   view.addObject("message",userName);
	   
      return view;
   }
   
   // 회원가입 폼 
   @RequestMapping(value="/userInfo/insertForm.do")
   public ModelAndView insertForm() {
	   
	   ModelAndView view = new ModelAndView("userInfo/insertForm");   
      return view;
   }
   
   
   @RequestMapping(value="/userInfo/updateForm.do")
   public ModelAndView updateForm(
		   @RequestParam(value="userId", required=true) String userId
		   ) {
	   
	   ModelAndView view = new ModelAndView("userInfo/updateForm");
	   view.addObject("obj",userInfoService.select(userId));
	   
      return view;
   }
   
   
   
   
   //// 인서트 부분 
  @RequestMapping(value="/userInfo/insert.do")
   public ModelAndView insert(UserInfoVo vo) {
	   // vo 를 넘기는 이유는 param1 이라는 글자로 jsp 파일에서 똑같이 매핑 시켜줌
	   userInfoService.insert(vo); // 
	   
	   ModelAndView view = new ModelAndView("redirect:/userInfo/view.do");   

	   view.addObject("userId",vo.getUserId());
	   view.addObject("userName","성공");
      return view;
   }

   
   @RequestMapping(value="/userInfo/update.do")
   public ModelAndView update(UserInfoVo vo) throws Exception {
	   userInfoService.update(vo);
	   
	   ModelAndView view = new ModelAndView("redirect:/userInfo/view.do");
	   view.addObject("userId",vo.getUserId());
	   view.addObject("userName","성공");
      return view;
   }
   
   
   @RequestMapping(value="/userInfo/delete.do")
   public ModelAndView delete(
		   @RequestParam(value="userId", required=true) String userId
		   ) throws Exception {
	   userInfoService.delete(userId);
	   
	   ModelAndView view = new ModelAndView("redirect:/userInfo/list.do");
	   
      return view;
   }
     
   


}
