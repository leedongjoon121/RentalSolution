package maven_project;

import com.woongjin.util.EncryptUti;

public class EncryptUtilTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       try {
    	   System.out.println(EncryptUti.getEncMD5("cody"));
       }catch(Exception e) {
    	   e.printStackTrace();
       }
	}

}
