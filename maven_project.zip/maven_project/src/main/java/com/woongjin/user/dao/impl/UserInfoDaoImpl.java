package com.woongjin.user.dao.impl;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.user.dao.UserInfoDao;
import com.woongjin.user.search.UserInfoSearch;
import com.woongjin.user.vo.UserInfoVo;;

@Repository
public class UserInfoDaoImpl implements UserInfoDao{
   
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	//private final static String MAPPER = "home.homeDao.";
	private final static String MAPPER = "user.userDao.";
	
	@Override
	public List<UserInfoVo> selectList(UserInfoSearch search){
		return query.selectList(MAPPER+"selectList", search);
	}
	
	@Override
	public int selectListCount(UserInfoSearch search) {
		return query.selectOne(MAPPER+"selectListCount",search);
	}

	@Override
	public UserInfoVo select(String userId) {
		// TODO Auto-generated method stub
		 return query.selectOne(MAPPER+"select",userId);
	}

	@Override
	public void insert(UserInfoVo vo) {
		// TODO Auto-generated method stub
		 query.insert(MAPPER+"insert",vo);
	}

	@Override
	public void update(UserInfoVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"update",vo);
	}

	@Override
	public void delete(String userId) {
		// TODO Auto-generated method stub
		query.delete(MAPPER+"delete",userId);
	}


}
