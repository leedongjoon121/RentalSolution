package com.woongjin.support.search;

import com.woongjin.util.Search;

public class FileInfoSearch extends Search{

}
