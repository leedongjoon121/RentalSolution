package com.woongjin.support.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.support.service.FileInfoService;
import com.woongjin.support.vo.FileInfoVo;
import com.woongjin.util.exception.AjaxException;

@Controller
public class FileInfoController {
   @Autowired
   private FileInfoService fileInfoService;
   
   /**
    * 
    * @return
    */
   @RequestMapping(value="/fileInfo/list.do")
   public ModelAndView list() {
	   ModelAndView view = new ModelAndView("fileInfo/list");
	   view.addObject("fileList", fileInfoService.selectList());
	   
	   return view;
	   
   }
   
   @RequestMapping(value="/fileInfo/list.json")
   public @ResponseBody Map<String,Object> listJson() {
	   
	   Map<String,Object> resultMap = new HashMap<String,Object>();
	   try {
		   resultMap.put("fileList", fileInfoService.selectList());
		   resultMap.put("message","OK");
	   }catch(Exception e) {
		   throw new AjaxException("FileInfo", e.toString());
	   }
	   return resultMap;
	   
   }
   
   
   
   /**
    * 
    * @param fileInfoVo
    * @return
    */
    
   @RequestMapping(value="/fileInfo/upload.do")
   public ModelAndView upload(
		   FileInfoVo fileInfoVo
		   ) {
	   ModelAndView view = new ModelAndView("redirect:/fileInfo/list.do");
	   fileInfoService.insert(fileInfoVo.getMultipartFiles());
	   
	   return view;
   }
   
   @RequestMapping(value="/fileInfo/upload.json")
 public @ResponseBody Map<String,Object> uploadJson(
		 FileInfoVo fileInfoVo
		 ) {
	   
	   Map<String,Object> resultMap = new HashMap<String,Object>();
	   try {
		   fileInfoService.insert(fileInfoVo.getMultipartFiles());
		   resultMap.put("message","OK");
	   }catch(Exception e) {
		   throw new AjaxException("FileInfo", e.toString());
	   }
	   return resultMap;
	   
   }
   
/**
 * 
 * @param fileId
 * @param response
 */
   @RequestMapping(value="/fileInfo/download.do")
   public void  download(
		   @RequestParam(value="fileId", required=true) String fileId,
		   HttpServletRequest request,
		   HttpServletResponse response
		   ) {

	   fileInfoService.downloadFile(request, response, fileId);
   }
   
   /**
    * 
    * @param fileId
    * @param response
    * @return
    */
   @RequestMapping(value="/fileInfo/delete.do")
   public ModelAndView delete(
		   @RequestParam(value="fileId", required=true) String fileId,
		   HttpServletResponse response
		   ) {
	   ModelAndView view = new ModelAndView("redirect:/fileInfo/list.do");
	   fileInfoService.delete(fileId);
	   
	   return view;
   }
   
   @RequestMapping(value="/fileInfo/delete.json")
 public @ResponseBody Map<String,Object> deleteJson(
		 @RequestParam(value="fileId", required=true) String fileId
		 ) {
	   
	   Map<String,Object> resultMap = new HashMap<String,Object>();
	   try {
		   fileInfoService.delete(fileId);
		   resultMap.put("message","OK");
	   }catch(Exception e) {
		   throw new AjaxException("FileInfo", e.toString());
	   }
	   return resultMap;
	   
   }
   
   
}
