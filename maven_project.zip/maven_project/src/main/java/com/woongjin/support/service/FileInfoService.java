package com.woongjin.support.service;

import java.io.FileInputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.woongjin.support.vo.FileInfoVo;

public interface FileInfoService {
	  public List<FileInfoVo> selectList(); 
	   
	   public int selectListCount();
	
	   public FileInfoVo select(String fileId);
	   
	   public List<FileInfoVo> insert(List<MultipartFile> multipartFiles); // 리스트형태로 넣는거
	   
	   public FileInfoVo insert(MultipartFile multipartFile); // 하나씩 넣는거 
	   
	   public void delete(String fileId);
	   
	   public void downloadFile(HttpServletRequest request, HttpServletResponse response, String fileId); 
	              // 파일 아이디가 db 조회해서 실제 파일 읽고 메모리상에 올려서 아래 메서드 호출
	   
	   public void downloadFile(HttpServletRequest request, HttpServletResponse response, String downloadFileName, FileInputStream fin); 
	              // 실제 정보들 가지고 다운로드 하는데 사용됨



      

}
