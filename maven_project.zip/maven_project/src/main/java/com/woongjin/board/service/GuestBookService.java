package com.woongjin.board.service;

import java.util.List;

import com.woongjin.board.search.GuestBookSearch;
import com.woongjin.board.vo.GuestBookVo;

public interface GuestBookService {
	
	  public List<GuestBookVo> selectList(GuestBookSearch search); 
	   
	   public int selectListCount(GuestBookSearch search);
	
	   public GuestBookVo select(String param1);
	   
	   public void insert(GuestBookVo vo);
	   
	   public void update(GuestBookVo vo);
	   
	   public void delete(String param1);
	   
}
