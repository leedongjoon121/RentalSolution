/* 
 * Copyright (C) 2015 Woongjin Inc.
 * All rights reserved.
 *
 * 모든 권한은 (주) 웅진(http://www.woongjin.co.kr)에 있으며,
 * (주) 웅진의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */
package com.woongjin.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;


/**
 * HttpUtil
 * 
 */
public final class HttpUtil {
	
	/* 임의의 값 생성을 위한 변수  */
	public static final int RANDOM_SIZE = 10;
	
	/* HttpUtil 클래스 생성자 */
	private HttpUtil() {
		throw new AssertionError();
	}

	/**
	 * 접속한 클라이언트 브라우져 타입을 반환하는 메소드
	 * 
	 * @param request HttpServletRequest
	 * @return String 브라우져 타입
	 */
	public static String getBrowser(HttpServletRequest request) {
		
		String[][] iBrowser;
		
		iBrowser = new String[][] { 
				// {user-agent String , Internet Browser}
				{ "Trident/11.0", "IE 15" },{ "Trident/10.0", "IE 14" }, { "Trident/9.0", "IE 13" }, { "Trident/8.0", "IE 12" },
				{ "Trident/7.0", "IE 11" },{ "Trident/6.0", "IE 10" }, { "Trident/5.0", "IE 9" }, { "Trident/4.0", "IE 8" }, 
				{ "MSIE 7.0", "IE 7" }, { "MSIE 6.0", "IE 6" }, { "MSIE 5.5", "IE 5.5" }, { "MSIE 5.0", "IE 5" }, { "MSIE 4.01", "IE 4.01" }, 
				{ "Android", "Android" }, { "Firefox", "Firefox" }, { "Chrome", "Chrome" }, { "Safari", "Safari" }, { "Opera", "Opera" }
			};
		
		String browser = "Unknown";
		
		String agentString = request.getHeader("User-Agent");

		for (int i = 0; i < iBrowser.length; i++) {
			if (agentString.toLowerCase().indexOf(iBrowser[i][0].toLowerCase()) > -1) {
				browser = iBrowser[i][1];

				// Chrome Browser는 애플웹엔진을 사용하므로, useragent에 safari, chrome 둘다
				// 포함되어 있다. 따라서, chrome이면 루프를 빠져나온다.
				if ("chrome".equals(iBrowser[i][0].toLowerCase()) || "android".equals(iBrowser[i][0].toLowerCase())) {
					break;
				}
			}
		}
		
		return browser;		
		
	}

	/**
	 * 브라우져 타입별 한글 인코딩된 파일명 반환하는 메소드
	 * 
	 * @param filename 인코딩할 파일명
	 * @param browser 사용자 브라우저 타입
	 * @return String 인코딩된 파일명
	 * @throws UnsupportedEncodingException
	 */
	public static String getDisposition(String filename, String browser) throws UnsupportedEncodingException {

		String dispositionPrefix = "";
		String encodedFilename = null;

		
		
		if (browser.indexOf("IE ")>-1) {
			encodedFilename = URLEncoder.encode(filename, "UTF-8").replaceAll("\\+", "%20");
		} else if (browser.indexOf("Firefox")>-1) {
			encodedFilename =

			"\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.indexOf("Opera")>-1) {
			encodedFilename =

			"\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.indexOf("Chrome")>-1) {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < filename.length(); i++) {
				char c = filename.charAt(i);
				if (c > '~') {
					sb.append(URLEncoder.encode("" + c, "UTF-8"));
				} else {
					sb.append(c);
				}
			}
			encodedFilename = sb.toString();
		} else if(browser.indexOf("Safari")>-1){
			//사파리 브라우저는 아직 검증되지 않았음
			encodedFilename =

			"\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";			
		} else if (browser.indexOf("Unknown")>-1) {
			// mobile 에서 이미지 파일 호출시 값이 없음
			encodedFilename = 
	
			"\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.indexOf("Android")>-1) {
			// mobile 에서 이미지 파일 호출시 값이 없음
			encodedFilename = 
	
			"\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} 

		return dispositionPrefix + encodedFilename;
	}


	
	/**
	 * Client IP를 반환하는 메소드
	 * @param request HttpServletRequest
	 * @return String 클라이언트 IP
	 */
	public static String getClientIP(HttpServletRequest request) {
		String ip = request.getHeader("Proxy-Client-IP");
		if (null == ip || ip.length() == 0 || ip.toLowerCase().equals("unknown")) {
			ip = request.getHeader("WL-Proxy-Client-IP");
			if (null == ip || ip.length() == 0 || ip.toLowerCase().equals("unknown")) {
				ip = request.getHeader("X-Forwarded-For");
				if (null == ip || ip.length() == 0 || ip.toLowerCase().equals("unknown")) {
					ip = request.getHeader("HTTP_X_FORWARDED_FOR");
					if (null == ip || ip.length() == 0 || ip.toLowerCase().equals("unknown")) {
						ip = request.getHeader("REMOTE_ADDR");
						if (null == ip || ip.length() == 0 || ip.toLowerCase().equals("unknown")) {
							ip = request.getRemoteAddr();
						}
					}
				}
			}
		}
		return ip;
	}
}
