package com.woongjin.home.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.home.search.HomeSearch;
import com.woongjin.home.service.HomeService;
import com.woongjin.home.vo.HomeVo;
import com.woongjin.util.exception.GenericException;


@Controller
public class HomeController {
   @Autowired
   private HomeService homeService;
   

// ------------------------------------------------------------------  
   
   
   @RequestMapping(value="/home/list.do")
   public ModelAndView list(HomeSearch search) {
	   
	   search.calculate(homeService.selectListCount(search));
	   ModelAndView view = new ModelAndView("home/list");
	   view.addObject("list",homeService.selectList(search));
	   view.addObject("search", search);
      return view;
   }
   
   // 이걸로 웹에 json 뿌림 
   @RequestMapping(value="/home/list.json")
   public @ResponseBody Map<String,Object> list2(HomeSearch search) {
	   
	   search.calculate(homeService.selectListCount(search));
	   Map<String,Object> resultMap = new HashMap<String,Object>();
       resultMap.put("list", homeService.selectList(search));
	   return resultMap;
   }
   
   // view는 각 list의 상세 값들 나타내는 것들 임
   @RequestMapping(value="/home/view.do")  
   public ModelAndView view(
		   @RequestParam(value="param1", required=true) String param1,
		   @RequestParam(value="message", required=false) String message
		   ) {
	   
	   ModelAndView view = new ModelAndView("home/view");
	   view.addObject("obj",homeService.select(param1));
	   view.addObject("message",message);
	   
      return view;
   }
   
   
   @RequestMapping(value="/home/insertForm.do")
   public ModelAndView insertForm() {
	   
	   ModelAndView view = new ModelAndView("home/insertForm");   
      return view;
   }
   
   
   @RequestMapping(value="/home/updateForm.do")
   public ModelAndView updateForm(
		   @RequestParam(value="param1", required=true) String param1
		   ) {
	   
	   ModelAndView view = new ModelAndView("home/updateForm");
	   view.addObject("obj",homeService.select(param1));
	   
      return view;
   }
   
   
   
   
   ////
   
   
   @RequestMapping(value="/home/insert.do")
   public ModelAndView insert(HomeVo vo) {
	   // vo 를 넘기는 이유는 param1 이라는 글자로 jsp 파일에서 똑같이 매핑 시켜줌
	   homeService.insert(vo);
	   
	   ModelAndView view = new ModelAndView("redirect:/home/view.do");
	   view.addObject("param1",vo.getParam1());
	   view.addObject("message","성공");
      return view;
   }

   
   @RequestMapping(value="/home/update.do")
   public ModelAndView update(HomeVo vo) {
	   homeService.update(vo);
	   
	   ModelAndView view = new ModelAndView("redirect:/home/view.do");
	   view.addObject("param1",vo.getParam1());
	   view.addObject("message","성공");
      return view;
   }
   
   
   @RequestMapping(value="/home/delete.do")
   public ModelAndView delete(
		   @RequestParam(value="param1", required=true) String param1
		   ) {
	   homeService.delete(param1);
	   
	   ModelAndView view = new ModelAndView("redirect:/home/list.do");
	   
      return view;
   }
     
   
   
   
// ------------------------------------------------------------------   
// 나머지는 response 에 파라미터로 request로 전달 해준다 .
	@RequestMapping(value="/showMessage2.do")
	public String showMessage2(Model model) {

		model.addAttribute("message", "Hello World!!");
		return "showMessage";
	}


	@RequestMapping(value="/showMessage5.do") // method 타입을 명시 안해주면 get, post 둘다 받을 수 있음
	public ModelAndView showMessage3() {

        ModelAndView view = new ModelAndView("showMessage");
        view.addObject("message", "Hello World!!");
		return view;  // model and view 는 반드시 인스턴스를 리턴 해줘야 한다.
	}
	
	@RequestMapping(value="/showMessage4.do")
	public @ResponseBody String showMessage4(ModelMap modelMap) {  // 바로 화면에 뿌려줌  -> 보통 json 타입 올릴때 사용

		return "<h2>fefefe</h2>";
		
	}
	
	@RequestMapping(value="/showMessage.do")
	public String showMessage(ModelMap modelMap) {

		modelMap.put("message", "Hello World!!");
		return "showMessage";
	}
	
	@RequestMapping(value="/testIOException.do")
	public String testIOException() throws IOException {

		if(true)throw new IOException("this is an IO Exception");
		return "showMessage";
	}
	
	@RequestMapping(value="/testGenericException.do")
	public String testGenericException() throws GenericException {

		if(true)throw new GenericException("GenericException","this is an GenericException");
		return "showMessage";
	}
}
