package com.woongjin.question.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.question.dao.QuestionDao;
import com.woongjin.question.vo.QuestionVo;
import com.woongjin.survey.search.SurveySearch;

@Repository
public class QuestionDaoImpl implements QuestionDao{
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "questiondao.";
	@Override
	public QuestionVo select(String param1) {
		// TODO Auto-generated method stub
		 return query.selectOne(MAPPER+"select",param1);
	}

	@Override
	public void insert(QuestionVo vo) {
		// TODO Auto-generated method stub
		query.insert(MAPPER+"insert",vo);
	}

	@Override
	public void update(QuestionVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"update",vo);
	}

	@Override
	public void delete(String param1) {
		// TODO Auto-generated method stub
		query.delete(MAPPER+"delete",param1);
	}

	@Override
	public List<QuestionVo> selectList(SurveySearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList", search);
	}

	@Override
	public List<QuestionVo> selectListval(String surId) {
		// TODO Auto-generated method stub
		System.out.println("questionDao Impl 안인데 받아온 surid: "+surId);
		return query.selectList(MAPPER+"selectList",surId);
	}

	@Override
	public void updateALsur(QuestionVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"allupdate",vo);
	}

}
