package com.woongjin.login.vo;

import java.io.Serializable;
public class LoginVo implements Serializable{

	
	 private static final long serialVersionUID = 683533578309880137L;
	 private String userId;
	 private String password;
	 private String LOG_TYPE; // 어떤 API로 로그인 했는지 
	 private String email;
	 


	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLOG_TYPE() {
		return LOG_TYPE;
	}
	public void setLOG_TYPE(String lOG_TYPE) {
		LOG_TYPE = lOG_TYPE;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	 
}
