package com.woongjin.login.dao;

import java.util.List;

import com.woongjin.login.search.LoginSearch;
import com.woongjin.login.vo.LoginVo;
import com.woongjin.survey.search.SurveySearch;

public interface LoginDao {
	
	public LoginVo select(String userId);   
	public List<LoginVo> selectList(LoginSearch search);
	public int selectListCount(SurveySearch search);
	public void insert(LoginVo vo);
	public void update(LoginVo vo);
	public void delete(String userId);
		
}
