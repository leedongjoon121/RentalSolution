package com.woongjin.login.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.login.service.LoginService;
import com.woongjin.login.vo.LoginVo;
import com.woongjin.user.service.UserInfoService;
import com.woongjin.user.vo.UserInfoVo;
import com.woongjin.util.BaseController;

@Controller
public class LoginController extends BaseController{
     
	
	@Autowired
	private UserInfoService userInfoService;
	
	@Autowired
	private LoginService loginService;
	
	@RequestMapping(value="/login/loginForm.do")
     public String loginForm(
    		 @RequestParam(value="errorMessage",required=false, defaultValue="") String errorMessage,
    		 ModelMap model
    		 ) {
		model.addAttribute("errorMessage",errorMessage);
		return "/login/loginForm";
    	 
     }
     
	
	// 데이터베이스에 있는 데이터 인지 체크함 (회원 가입 되어 있는 디비인지 확인)
	// api가 아닌, 일반 앱으로 로그인 했을 경우 
     @RequestMapping(value="/login/login.do")
     public ModelAndView login(HttpServletRequest request, LoginVo loginVo) throws Exception {
    	 
    	 ModelAndView view;
         String login_id,login_pw,login_type;
         
         
      if(request.getParameter("email")==null){ // 일반 사용자 인 경우 
         
        //////////////////////////////////////// 일반 사용자 //////////////////////////////////////////////////////
		// login_id = request.getParameter("userId");
		// login_pw = request.getParameter("password");
		 
                    
    	 UserInfoVo userInfo =  userInfoService.select(loginVo.getUserId());// 데이터베이스에 데이터가 있으면 객체를 생성 할 수 잇어서 
    	                                                                      // 아래의 if문에 null이 아닌 값이 된다.
    	 login_type= userInfo.getType();
    	 System.out.println("로그인 타입은 : "+userInfo.getType());
    	 System.out.println("아이디 : "+userInfo.getUserId());
    	 System.out.println("이름 : "+userInfo.getUserName());
    	 
    	 if(userInfo.getType().equals("cody")) { // 코디로 들어 왔을 경우 
    		 System.out.println("코디로 접속 함");
    		  view = new ModelAndView("redirect:/survey/showlist.do");
    	 }else if(userInfo.getType().equals("admin")) {
    		 System.out.println("관리자로 접속 함");
    		 view = new ModelAndView("redirect:/survey/showsurId.do");
    	 }else {
    		 System.out.println("일반 사용자로 로그인 함 ");
    		 view =  new ModelAndView("redirect:/survey/general_showlist.do");
    	 }
    	 
    	 /*
    	 if(login_id.equals("cody") && login_pw.equals("cody")) { // 코디로 들어 왔을 경우 
    		 System.out.println("코디로 접속 함");
    		  view = new ModelAndView("redirect:/survey/showlist.do");
    	 }else if(login_id.equals("admin") && login_pw.equals("admin")) {
    		 System.out.println("관리자로 접속 함");
    		 view = new ModelAndView("redirect:/survey/showsurId.do");
    	 }else {
    		 System.out.println("일반 사용자로 로그인 함 ");
    		 view =  new ModelAndView("redirect:/survey/general_showlist.do");
    	 }
    	*/
    	 
    	 // 사용자 체크
    	 if(userInfo == null) {
    		 view.setViewName("redirect:/login/loginForm.do");
    		 view.addObject("errorMessage", "사용자가 존재하지 않습니다"); // 에러가 발생하면 loginForm 함수에 전달됨
    		 
    		 return view;
    	 }
    	 
    	 //String encPw = EncryptUti.getEncMD5(loginVo.getPassword()); // 비밀번호 암호화
    	 
    	 //비밀번호 체크
    	 if(!userInfo.getPassword().equalsIgnoreCase(loginVo.getPassword())) {  // equalsIgnoreCase : 대소문자를 가려서 체크함
    		 view.setViewName("redirect:/login/loginForm.do");
    		 view.addObject("errorMessage", "비밀번호를 확인해 주세요 ");
    		 
    		 return view;
    	 }
    	 loginVo.setLOG_TYPE("general");
    	 loginService.insert(loginVo); // 로그인 기록 남기는거 : loginlog 테이블
    	 
    	
    	 setRequestAttribute("userInfo",userInfo);
    	 setRequestAttribute("userId",loginVo.getUserId());   // Surveycontroller로 usreId 전달 함, 현재 로그인한 아이디 값 전달용
          //////////////////////////////////////일반 사용자 //////////////////////////////////////////////////////
         }else{
        	 //////////////////////////////////////////////////// API 로그인 /////////////////////////////////////////////////////
        	 String email;
        	 email = request.getParameter("email");
        	 
        	 UserInfoVo userInfo =  userInfoService.selectem(email);// 데이터베이스에 데이터가 있으면 객체를 생성 할 수 잇어서 
        	 UserInfoVo APIuserInfo =  userInfoService.select("API_LOGIN");
           	 
        	 view  = new ModelAndView("redirect:/survey/general_showlist.do");
        	 
        	 // 이미 가입된 사용자 인지 체크 -> 가입이 안되어 있는 사용자 일경우    //  LOG_TYPE
        	 if(userInfo == null) {
        		 loginVo.setUserId(email);
        		 setRequestAttribute("userId",email);   // Surveycontroller로 usreId 전달 함, 현재 로그인한 아이디 값 전달용
        	 }else { // 가입이 되어 있는 경우라면 
        		 loginVo.setUserId(userInfo.getUserId());
        		 setRequestAttribute("userId",userInfo.getUserId());
        	 }
        	 loginVo.setLOG_TYPE("naver");
        	 loginService.insert(loginVo); // 로그인 기록 남기는거 : loginlog 테이블
        	 // userinfo에 업데이트 해야함 -> email에 현재 email로
        	 setRequestAttribute("userId",email);
        	 setRequestAttribute("userInfo",APIuserInfo);
         }
    	 
    	 return view;
     }
     
     
     
     //api로 로그인 했을 경우
    /*
     @RequestMapping(value="/login/apilogincont.do")
     public ModelAndView apilogin(HttpServletRequest request, LoginVo loginVo) throws Exception {
    	 
    	 String email;
    	 //email = loginVo.getEmail();
    	 email = request.getParameter("email");
    	 System.out.println("가져온 email 확인 "+email);

    	 UserInfoVo userInfo =  userInfoService.selectem(email);// 데이터베이스에 데이터가 있으면 객체를 생성 할 수 잇어서 
   	 
    	 ModelAndView view  = new ModelAndView("redirect:/survey/showsurId.do");
    	 
    	 // 이미 가입된 사용자 인지 체크 -> 가입이 안되어 있는 사용자 일경우    //  LOG_TYPE
    	 if(userInfo == null) {
    		 loginVo.setUserId(email);
    		 setRequestAttribute("userId",email);   // Surveycontroller로 usreId 전달 함, 현재 로그인한 아이디 값 전달용
    	 }else { // 가입이 되어 있는 경우라면 
    		 loginVo.setUserId(userInfo.getUserId());
    		 setRequestAttribute("userId",userInfo.getUserId());
    	 }
    	 loginVo.setLOG_TYPE("naver");
    	 loginService.insert(loginVo); // 로그인 기록 남기는거 : loginlog 테이블
    	 
    	 setRequestAttribute("userInfo",userInfo);
    	
 
    	 
    	 return view;
     }
     */
     
     @RequestMapping(value="/login/logout.do")
     public ModelAndView logout(HttpSession session) {
    	 session.invalidate();
    	 ModelAndView view = new ModelAndView("redirect:/login/loginForm.do");
    	 return view;
     }
     
     
     // API로 로그인 했을 때
     @RequestMapping(value="/login/APIlogin.do")
     public ModelAndView APIlogin(LoginVo loginVo) {
    	 
    	 ModelAndView view = new ModelAndView("/home/api_login");
    	 return view;
     }
     
     
}

