package com.woongjin.answer.vo;

public class AnswerVo {

	private String surId; // 답변 내용
    private String qstId;
    private String aswId;
    private String aswCont;
    
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public String getQstId() {
		return qstId;
	}
	public void setQstId(String qstId) {
		this.qstId = qstId;
	}
	public String getAswId() {
		return aswId;
	}
	public void setAswId(String aswId) {
		this.aswId = aswId;
	}
	public String getAswCont() {
		return aswCont;
	}
	public void setAswCont(String aswCont) {
		this.aswCont = aswCont;
	}
	
}
