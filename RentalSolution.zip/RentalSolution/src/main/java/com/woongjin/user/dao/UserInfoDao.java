package com.woongjin.user.dao;

import java.util.List;

import com.woongjin.user.search.UserInfoSearch;
import com.woongjin.user.vo.UserInfoVo;;

public interface UserInfoDao {
   public List<UserInfoVo> selectList(UserInfoSearch search); 
   
   public int selectListCount(UserInfoSearch search);
   /*
    * 상세
    * 
    * */
   public UserInfoVo select(String userId);
   
   public UserInfoVo selectem(String email);
   
   public void insert(UserInfoVo vo);
   
   public void update(UserInfoVo vo);
   
   public void delete(String userId);
  
}
