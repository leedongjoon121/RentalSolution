package com.woongjin.survey.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.submit.vo.SubmitVo;
import com.woongjin.survey.search.SurveySearch;
import com.woongjin.survey.service.SurveyService;
import com.woongjin.survey.vo.SurveyVo;
import com.woongjin.util.BaseController;



@Controller
public class SurveyController extends BaseController {
	   @Autowired
	   private SurveyService surveyService;
	   
	   
	   // 코디가 실제로 보는 설문지 
	   @RequestMapping(value="/survey/showlist.do")
	   public ModelAndView codylist(SurveySearch search) {
	       
		   ModelAndView view = new ModelAndView("home/surveylist");
		   String surId;
		   surId = surveyService.selUseList(search);  // surUse 가 Y인 값만 가져옴 
		   System.out.println("가져온 surId는 : "+surId);
		   
		   Map<String,Object> temp = surveyService.selval(surId); // 여기에 surId를 넣는 것이 핵심
		   		   		   
		   view.addObject("questionobj",temp.get("questionobj"));
		   view.addObject("answerobj",temp.get("answerobj"));
		   
		   
	      return view;
	   }
	   
	   // 일반사용자가 보는 설문지
	   @RequestMapping(value="/survey/general_showlist.do")
	   public ModelAndView generallist(SurveySearch search) {
	       
		   ModelAndView view = new ModelAndView("home/surveylist2");
		   String surId;
		   surId = surveyService.selUseList(search);  // surUse 가 Y인 값만 가져옴 
		   System.out.println("가져온 surId는 : "+surId);
		   
		   Map<String,Object> temp = surveyService.selval(surId); // 여기에 surId를 넣는 것이 핵심
		   		   		   
		   view.addObject("questionobj",temp.get("questionobj"));
		   view.addObject("answerobj",temp.get("answerobj"));
		   
		   
	      return view;
	   }
	   
	   // surId만 뿌리는 용도의 뷰 리턴 -> 관리자 계정에서 , 어떤 surId를 사용할 것인지 결정 
	   @RequestMapping(value="/survey/showsurId.do")
		public ModelAndView showsurId(SurveySearch search) {
			ModelAndView view = new ModelAndView("/home/selectsurvey");
			view.addObject("list",surveyService.selectList(search));
			return view;
		}
	   

	 // 설문지 선택  surUse 가  : Y인지 N인지 선택 할지 실제 로직
	   @RequestMapping(value="/survey/selectsurvey.do")
		public ModelAndView selectSurId(SurveyVo vo) {
		   surveyService.update2(); // N 으로 
		   surveyService.update(vo);
			ModelAndView view = new ModelAndView("redirect:/survey/showsurId.do");
			return view;
		}
	   
	   
	   // 인서트 뷰
	   @RequestMapping(value="/survey/insertSurvey.do")
		public ModelAndView insertSurvey(SurveyVo vo) {
		   //surveyService.insertSV(vo);
			ModelAndView view = new ModelAndView("/home/makesurvey");
			//redirect:/home/view.do
			return view;
		}
	   
	   @RequestMapping(value="/survey/insert.do")
		public ModelAndView insert(SurveyVo vo) {
		   surveyService.insertSV(vo);
			ModelAndView view = new ModelAndView("redirect:/survey/showsurId.do");
			
			return view;
		}
	   

	    // 설문조사 결과 값 서브밋 하는 곳 
	   @RequestMapping(value="/survey/insertSM.do")
	   public ModelAndView surveydb(SurveyVo vo) {		    
			surveyService.insertSM(vo);
			ModelAndView view = new ModelAndView("redirect:/survey/showresult.do"); // 원래 값
	      return view;
	   }
	   
	   // 설문조사 결과 값 서브밋 하는 곳 
	   @RequestMapping(value="/survey/insertSM2.do")
	   public ModelAndView surveydb2(SurveyVo vo) {		    
			surveyService.insertSM(vo);
			ModelAndView view = new ModelAndView("redirect:/survey/showresult2.do"); // 원래 값
	      return view;
	   }
	   
	   @RequestMapping(value="/survey/showresult.do")
	   public ModelAndView showresult(SurveyVo vo) {
   
		   ModelAndView view = new ModelAndView("/home/result"); // 설문 조사 완료 페이지
		   
	      return view;
	   }

	   @RequestMapping(value="/survey/showresult2.do")
	   public ModelAndView showresult2(SurveyVo vo) {
   
		   ModelAndView view = new ModelAndView("/home/result2"); // 설문 조사 완료 페이지
		   
	      return view;
	   }
	   
	   //  설문조사 수정 !!!!!!!!!!!!!!!! 
	   /// 관리자가 보는 모든 설문조사 수정 리스트  => 뷰 페이지
	   @RequestMapping(value="/survey/allsurveylist.do")
	   public ModelAndView showallsurlist(SurveySearch search) {
		   ModelAndView view = new ModelAndView("/home/all_survey"); // 모든 설문조사 리스트 페이지 
		   view.addObject("list",surveyService.selectList(search));
	       return view;
	   }
	   
	   // view는 각 list의 상세 값들 나타내는 것들 임 => 뷰 상세 값 페이지
	   @RequestMapping(value="/home/edit_surv.do")  
	   public ModelAndView showsurlist2(
			   @RequestParam(value="surId", required=true) String surId
			   ) {
		   
		   ModelAndView view = new ModelAndView("home/edit_all_survey");
		   
   		  System.out.println("가져온 surId는 : "+surId);
		   
		   Map<String,Object> temp = surveyService.selval(surId); // 여기에 surId를 넣는 것이 핵심
		   
		   view.addObject("surId", surId);		   		   
		   view.addObject("questionobj",temp.get("questionobj"));
		   view.addObject("answerobj",temp.get("answerobj"));
		   
	      return view;
	   }
	   // updateALLSV
	   
	   // 실제 설문지 업데이트 구현부분 
	   // 아직 해결 못함 ======================> 해결 하기
	   @RequestMapping(value="/survey/edit_surv_im.do")
	   public ModelAndView updateimpl(SurveyVo vo, HttpServletRequest request) {		
		   //System.out.println("surId"+vo.getSurId());
		   String surId = request.getParameter("surId");
		   System.out.println("surId : "+request.getParameter("surId"));
		   vo.setSurId(surId);
			surveyService.updateALLSV(vo);
			ModelAndView view = new ModelAndView("redirect:/home/edit_surv.do"); // 원래 값
	      return view;
	   }
	   
	   // surId만 뿌리는 용도의 뷰 리턴 -> 관리자 계정에서 , 어떤 surId를 사용할 것인지 결정 
	   @RequestMapping(value="/survey/showSubmit.do")
		public ModelAndView showSubmitList(SurveySearch search) {
			ModelAndView view = new ModelAndView("/admin/info_manage2");
			  List<SubmitVo> list = surveyService.selectListAL(search);
			  for(int i = 0; i<list.size();i++) {
//				  System.out.println("surId 값 테스트 : "+list.get(i).surId);
//				  System.out.println("qstId 값 테스트 : "+list.get(i).qstId);
//				  System.out.println("aswId 값 테스트 : "+list.get(i).aswId);
			  }
			  
			view.addObject("list",surveyService.selectListAL(search));
			
			return view;
		}
	   
	   // surId만 뿌리는 용도의 뷰 리턴 -> 관리자 계정에서 , 어떤 surId를 사용할 것인지 결정 
	   @RequestMapping(value="/survey/chartest.do")
		public ModelAndView charttest(SurveySearch search) {
			ModelAndView view = new ModelAndView("/admin/chart_test");
			return view;
		}
}
