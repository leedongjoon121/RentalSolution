package com.woongjin.survey.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.answer.dao.AnswerDao;
import com.woongjin.answer.vo.AnswerVo;
import com.woongjin.question.dao.QuestionDao;
import com.woongjin.question.vo.QuestionVo;
import com.woongjin.submit.dao.SubmitDao;
import com.woongjin.submit.vo.SubmitVo;
import com.woongjin.support.service.SeqInfoService;
import com.woongjin.survey.dao.SurveyDao;
import com.woongjin.survey.search.SurveySearch;
import com.woongjin.survey.service.SurveyService;
import com.woongjin.survey.vo.SurveyVo;
import com.woongjin.util.BaseController;



@Repository
public class SurveyServiceImpl extends BaseController implements SurveyService  {
	
	@Autowired
	private SurveyDao surveydao;

	@Autowired
	private QuestionDao questiondao;
	
	@Autowired
	private AnswerDao answerdao;
	
	@Autowired
	private SubmitDao submitdao;

	@Autowired
	SeqInfoService seqinfoservice;

	
	// 설문지 insert 
	@Override
	public void insertSV(SurveyVo vo) {
		// TODO Auto-generated method stub
		int Qcount = 0;
		int Acount  = 0;
		String seqinfoindex = seqinfoservice.getGuestBookNextId();
		vo.setSurId("S"+seqinfoindex);
		vo.setSurIndex(Integer.parseInt(seqinfoindex));
		String surId = vo.getSurId();            
		
		for( QuestionVo questionVo : vo.getQuestionList() ) {
		
			questionVo.setSurId(surId);
			String qId = "Q"+seqinfoindex+Qcount;

			 questionVo.setQstId(qId); // qid 지정
			 questionVo.setQstIndex(Qcount);
			 Qcount++;
			 
			 if(questionVo.getAnswerList()!=null) {
				 for( AnswerVo answerVo : questionVo.getAnswerList() ) {
					 answerVo.setSurId(surId);
					 answerVo.setQstId(qId);
					 answerVo.setAswId("A"+seqinfoindex+Acount);
					 Acount++;
					 answerdao.insert(answerVo);
				 }
				 
			 }	
		questiondao.insert(questionVo);	
		}
		vo.setSurUse("N"); // 일단은 N 으로
		surveydao.insert(vo);	
	}

	// 모든 설문지 수정 : 컨트롤러에서 vo.setSurId(surId) 로 셋팅 하고 호출 하면 될듯 함 
	@Override
	public void updateALLSV(SurveyVo vo) {
		// TODO Auto-generated method stub
		String surId = vo.getSurId(); 
	
		for( QuestionVo questionVo : vo.getQuestionList() ) {
			
			questionVo.setSurId(surId);
			 
			 
			 if(questionVo.getAnswerList()!=null) {
				 for( AnswerVo answerVo : questionVo.getAnswerList() ) {
					 answerVo.setSurId(surId);
					// answerVo.setQstId(qId);
					// answerVo.setAswId(answerVo.getAswId());
					 
					 answerdao.updateALsur(answerVo);
				 }
				 
			 }	
		questiondao.updateALsur(questionVo);	
		}
		
	}
	
	@Override
	public Map<String, Object> selval(String surId) {
		// TODO Auto-generated method stub
		
		System.out.println("selval인데 넘어온 값 : "+ surId);
		Map<String,Object> tempval = new HashMap<String,Object>();
			
		List<QuestionVo> qstList = questiondao.selectListval(surId);
		tempval.put("questionobj", qstList);

		for(QuestionVo vo : qstList) { // 여길 수정 해야 함
		    vo.setAnswerList(answerdao.selectListval(surId, vo.getQstId()));
		}
		return tempval;
	}
	



	@Override
	public List<SurveyVo> selectList(SurveySearch search) {
		// TODO Auto-generated method stub
		
		return surveydao.selectList(search);
	}
	

	@Override
	public int selectListCount(SurveySearch search) {
		// TODO Auto-generated method stub
		return surveydao.selectListCount(search);
	}


	// 서브밋 제출하는 부분 
	/*
	 * Surveyvo 또는 Submitvo 에다가 현재 접속중인 아이디를 담아서 같이 인서트 하면 끝
	 * */
	@Override
	public void insertSM(SurveyVo vo) {
		String Id;
		Id = (String) getRequestAttribute("userId");
		
	     for(SubmitVo svo : vo.getSubmitList()) {
	    	// if(svo.getId()==null) continue;
	    	 svo.setId(Id);
	    	 submitdao.insert(svo);
	    	 
	     }
	}


	@Override
	public void update(SurveyVo vo) {
		// TODO Auto-generated method stub
		 
		 surveydao.update(vo);
	}


	@Override
	public String selUseList(SurveySearch search) {
		// TODO Auto-generated method stub
		return surveydao.selUseList(search);
	}

	@Override
	public List<SubmitVo> selectListAL(SurveySearch search) {
		// TODO Auto-generated method stub
		return submitdao.selectListAl(search);
	}

	@Override
	public void update2() {
		// TODO Auto-generated method stub
		surveydao.update2();
	}

}
