package com.woongjin.survey.dao;

import java.util.List;

import com.woongjin.survey.search.SurveySearch;
import com.woongjin.survey.vo.SurveyVo;

	public interface SurveyDao {
	public SurveyVo select(String param1);   
	public List<SurveyVo> selectList(SurveySearch search);
	public void insert(SurveyVo vo);
	public void update(SurveyVo vo);
	public void update2(); //USE :  N으로 
	public void delete(String param1);
	public int selectListCount(SurveySearch search);
	public String selUseList(SurveySearch search);
	
}
