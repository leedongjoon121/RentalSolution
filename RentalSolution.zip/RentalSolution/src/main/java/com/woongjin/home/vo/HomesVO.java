package com.woongjin.home.vo;

import java.util.List;

public class HomesVO {

	List<HomeVo> homes;

	public List<HomeVo> getHomes() {
		return homes;
	}

	public void setHomes(List<HomeVo> homes) {
		this.homes = homes;
	}
	
}
