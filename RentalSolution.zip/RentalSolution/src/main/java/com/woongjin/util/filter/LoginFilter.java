package com.woongjin.util.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.woongjin.user.vo.UserInfoVo;

public class LoginFilter implements Filter {

	private static final String LOGIN_FORM_URI = "/login/loginForm.do";
	private List<String> urlList;

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
         this.urlList = new ArrayList<String>();
         this.urlList.add("/login/loginForm.do");
         this.urlList.add("/login/login.do");
         this.urlList.add("/userInfo/insertForm.do"); //회원가입 하는 url 허용 !
         this.urlList.add("/login/apilogin.do"); // api로 인증하는 url
         this.urlList.add("/login/apilogincont.do");
         this.urlList.add("/login/APIlogin.do");
         this.urlList.add("/userInfo/insert.do");
         
         
         
         // 
	}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
	    try {
	    	HttpServletRequest req = (HttpServletRequest) request;
	    	HttpServletResponse res = (HttpServletResponse) response;
	    	HttpSession session = ((HttpServletRequest)request).getSession();
	    	String url = req.getServletPath();
	    	if(urlList.contains(url)) {
	    		chain.doFilter(request, response);
	    		return;
	    	}else {
	    		UserInfoVo userInfo = (UserInfoVo)session.getAttribute("userInfo");
	    		if(userInfo!=null) {
	    			chain.doFilter(request, response);
	    			return;
	    		}else {
	    			res.sendRedirect(req.getContextPath()+LOGIN_FORM_URI);
	    		}
	    	}
	    }catch(Exception e) {
	    	e.printStackTrace();
	    }	
	}
	
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
}
