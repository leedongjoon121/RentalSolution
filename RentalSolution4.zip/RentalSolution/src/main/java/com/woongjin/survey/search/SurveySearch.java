package com.woongjin.survey.search;

import com.woongjin.util.Search;

public class SurveySearch extends Search {

}
