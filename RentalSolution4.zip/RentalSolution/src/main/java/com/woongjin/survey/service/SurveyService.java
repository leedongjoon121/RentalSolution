package com.woongjin.survey.service;

import java.util.List;
import java.util.Map;

import com.woongjin.survey.search.SurveySearch;
import com.woongjin.survey.vo.SurveyVo;

public interface SurveyService {
	
	//   public SurveyVo select(String param1);
	
	
	public List<SurveyVo> selectList(SurveySearch search); 
	   public void insertSV(SurveyVo vo); // 설문지 
	  // public SurveyVo selectVal(SurveyVo vo);
	public int selectListCount(SurveySearch search);
	    public Map<String,Object> selval(String surId);
	
	    
	   
	   
	  // public void insertQU(QuestionVo vo); // 답변
	  // public void insertAN(AnswerVo vo); // 질문지
	  // public void insert(SurveyVo Svo, QuestionVo Qvo, AnswerVo Avo);
	  // public void update(SurveyVo vo);
	   
	   //public void delete(String param1);
}
