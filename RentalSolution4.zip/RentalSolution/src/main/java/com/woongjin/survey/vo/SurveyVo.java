package com.woongjin.survey.vo;

import java.util.List;

import com.woongjin.question.vo.QuestionVo;


public class SurveyVo {

	private String surTitle; // 설문지 제목
	private String surIndex;
	private String surId;
	private String surDate;
	private String surUse;
	
	private List<QuestionVo> questionList;

	public String getSurTitle() {
		return surTitle;
	}

	public void setSurTitle(String surTitle) {
		this.surTitle = surTitle;
	}

	public String getSurIndex() {
		return surIndex;
	}

	public void setSurIndex(String surIndex) {
		this.surIndex = surIndex;
	}

	public String getSurId() {
		return surId;
	}

	public void setSurId(String surId) {
		this.surId = surId;
	}

	public String getSurDate() {
		return surDate;
	}

	public void setSurDate(String surDate) {
		this.surDate = surDate;
	}

	public String getSurUse() {
		return surUse;
	}

	public void setSurUse(String surUse) {
		this.surUse = surUse;
	}

	public List<QuestionVo> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<QuestionVo> questionList) {
		this.questionList = questionList;
	}

	//private String surId = UUID.randomUUID().toString(); // 설문지 번호
	
	



	
}
