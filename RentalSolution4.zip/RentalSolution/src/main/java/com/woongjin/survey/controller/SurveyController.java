package com.woongjin.survey.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.survey.service.SurveyService;
import com.woongjin.survey.vo.SurveyVo;



@Controller
public class SurveyController {
	   @Autowired
	   private SurveyService surveyService;
	   
		
	   @RequestMapping(value="/survey/showlist.do")
	   public ModelAndView list(String surId) {
		   
	
		   ModelAndView view = new ModelAndView("home/surveylist");

		   
		   Map<String,Object> temp = surveyService.selval(surId);
		   
		   view.addObject("surveyobj",temp.get("surveyobj"));
		   view.addObject("questionobj",temp.get("questionobj"));
		   view.addObject("answerobj",temp.get("answerobj"));
		   
	      return view;
	   }
	   
	   // 인서트 뷰
	   @RequestMapping(value="/survey/insertSurvey.do")
		public ModelAndView insertSurvey(SurveyVo vo) {
		   //surveyService.insertSV(vo);
			ModelAndView view = new ModelAndView("/home/makesurvey");
			//redirect:/home/view.do
			return view;
		}
	   
	   @RequestMapping(value="/survey/insert.do")
		public ModelAndView insert(SurveyVo vo) {
		   surveyService.insertSV(vo);
			ModelAndView view = new ModelAndView("redirect:/survey/showlist.do");
			//redirect:/home/view.do
			return view;
		}
}
