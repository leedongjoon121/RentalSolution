package com.woongjin.survey.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.answer.dao.AnswerDao;
import com.woongjin.answer.vo.AnswerVo;
import com.woongjin.question.dao.QuestionDao;
import com.woongjin.question.vo.QuestionVo;
import com.woongjin.survey.dao.SurveyDao;
import com.woongjin.survey.search.SurveySearch;
import com.woongjin.survey.service.SurveyService;
import com.woongjin.survey.vo.SurveyVo;



@Repository
public class SurveyServiceImpl implements SurveyService {
	
	@Autowired
	private SurveyDao surveydao;

	@Autowired
	private QuestionDao questiondao;
	
	@Autowired
	private AnswerDao answerdao;
	
	


	@Override
	public void insertSV(SurveyVo vo) {
		// TODO Auto-generated method stub
		String surId = vo.getSurId();
		for( QuestionVo questionVo : vo.getQuestionList() ) {
		
			questionVo.setSurId(surId);
			 //String qId= "34" ;   // 랜덤이나 일정한 변수로 지정하기
			String qId = UUID.randomUUID().toString();
			 questionVo.setQstId(qId); // qid 지정
			 questionVo.setQstIndex(1);
			 if(questionVo.getAnswerList()!=null) {
				 for( AnswerVo answerVo : questionVo.getAnswerList() ) {
					 answerVo.setSurId(surId);
					 answerVo.setQstId(qId);
					 answerdao.insert(answerVo);
				 }		 
			 }	
			questiondao.insert(questionVo);	
		}
		surveydao.insert(vo);	
	}

	
	@Override
	public Map<String, Object> selval(String surId) {
		// TODO Auto-generated method stub
		Map<String,Object> tempval = new HashMap<String,Object>();

		
		
		tempval.put("surveyobj", surveydao.select(surId));
		
		List<QuestionVo> qstList = questiondao.selectListval(surId);
		tempval.put("questionobj", qstList);

		for(QuestionVo vo : qstList) {
		    vo.setAnswerList(answerdao.selectListval(surId, vo.getQstId()));
		}
		
		  
	//	tempval.put("answerobj", answerdao.selectListval(surId));   
		return tempval;
	}
	



	@Override
	public List<SurveyVo> selectList(SurveySearch search) {
		// TODO Auto-generated method stub
		
		return surveydao.selectList(search);
	}

	@Override
	public int selectListCount(SurveySearch search) {
		// TODO Auto-generated method stub
		return surveydao.selectListCount(search);
	}

	

   


	
	

}
