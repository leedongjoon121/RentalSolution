package com.woongjin.answer.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.answer.dao.AnswerDao;
import com.woongjin.answer.vo.AnswerVo;
import com.woongjin.survey.search.SurveySearch;

@Repository
public class AnswerDaoImpl implements AnswerDao{
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	
	private final static String MAPPER = "answerdao.";
	
	@Override
	public AnswerVo select(String param1) {
		// TODO Auto-generated method stub
		 return query.selectOne(MAPPER+"select",param1);
	}

	
	@Override
	public List<AnswerVo> selectList(SurveySearch search){
		return query.selectList(MAPPER+"selectList", search);
	}
	
	@Override
	public void insert(AnswerVo vo) {
		// TODO Auto-generated method stub
		query.insert(MAPPER+"insert",vo);
	}

	@Override
	public void update(AnswerVo vo) {
		// TODO Auto-generated method stub
		query.update(MAPPER+"update",vo);
	}

	@Override
	public void delete(String param1) {
		// TODO Auto-generated method stub
		query.delete(MAPPER+"delete",param1);
	}


	@Override
	public List<AnswerVo> selectListval(String surId, String qstId) {
		// TODO Auto-generated method stub
		Map<String,Object> tempMap = new HashMap<String,Object>();
		tempMap.put("surId",surId );
		tempMap.put("qstId", qstId);
		return  query.selectList(MAPPER+"selectList",tempMap);
	}

}
