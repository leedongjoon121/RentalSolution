package com.woongjin.home.search;

import com.woongjin.util.Search;
public class HomeSearch extends Search{
   
}
