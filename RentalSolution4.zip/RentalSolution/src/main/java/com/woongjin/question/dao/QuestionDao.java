package com.woongjin.question.dao;

import java.util.List;

import com.woongjin.question.vo.QuestionVo;
import com.woongjin.survey.search.SurveySearch;

public interface QuestionDao {
	  public QuestionVo select(String param1);
	   
	  public List<QuestionVo> selectList(SurveySearch search); 
	  
	  public List<QuestionVo> selectListval(String surId);
	  
	   public void insert(QuestionVo vo);
	   
	   public void update(QuestionVo vo);
	   
	   public void delete(String param1);
}
