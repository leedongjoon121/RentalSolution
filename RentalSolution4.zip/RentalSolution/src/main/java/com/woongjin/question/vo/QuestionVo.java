package com.woongjin.question.vo;

import java.util.List;

import com.woongjin.answer.vo.AnswerVo;

public class QuestionVo {

	private String surId; // 질문 내용 
	private String qstId;
	private int qstIndex;
	private String qstCont;
	
	private List<AnswerVo> answerList;

	public String getSurId() {
		return surId;
	}

	public void setSurId(String surId) {
		this.surId = surId;
	}

	public String getQstId() {
		return qstId;
	}

	public void setQstId(String qstId) {
		this.qstId = qstId;
	}

	public int getQstIndex() {
		return qstIndex;
	}

	public void setQstIndex(int qstIndex) {
		this.qstIndex = qstIndex;
	}

	public String getQstCont() {
		return qstCont;
	}

	public void setQstCont(String qstCont) {
		this.qstCont = qstCont;
	}

	public List<AnswerVo> getAnswerList() {
		return answerList;
	}

	public void setAnswerList(List<AnswerVo> answerList) {
		this.answerList = answerList;
	}


	
	
	
}
