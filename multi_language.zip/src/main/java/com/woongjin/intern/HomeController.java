package com.woongjin.intern;


import java.util.Locale;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	LocaleResolver localeResolver;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	
	/*
	 * localhost:8080/ 으로 접속시
	 * /myomee.do 로 포워딩
	 * 
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model ) {
		return "redirect:myomee.do";
	}
	
	
	
	/*
	 * /message.do 로 접속시
	 * home.jsp 를 띄운다
	 * 
	 */
	@RequestMapping(value = "/message.do")
	public String message(Locale locale, Model model,HttpServletRequest httpServletRequest) {

		return "home";
	}	
	
	
	
	/*
	 * /anotherPage.do 로 접속시
	 * anotherPage.jsp 를 띄운다
	 * 
	 */
	@RequestMapping(value = "/anotherPage.do")
	public String anotherPage(Locale locale, Model model,HttpServletRequest httpServletRequest) {

		return "anotherPage";
	}
	
	
	/*  localhost:8080/로 접속해서  /myomee.do로 포워딩 되면 이 함수가 실행됨 */
	@RequestMapping(value = "/myomee.do")
	public String myomee(Locale locale, Model model,HttpServletRequest request,HttpServletResponse response ) {

		/*
		 * 한국어 버튼 클릭시, /myomee.do?language=ko
		 * 일본어 버튼 클릭시, /myomee.do?language=ja
		 * 영어 버튼 클릭시, /myomee.do?language=en
		 * */
		String language= request.getParameter("language"); 
		
		/* HttpSession이 존재하면 현재 HttpSession을 반환하고 존재하지 않으면 새로이 생성하지 않고 그냥 null을 반환*/
	    HttpSession session = request.getSession(false); 
	     
	    /*
	     * 세션에 값이 있으면 모든 세션을 비워버린다... 세션이 있는데 굳이 초기화 하는 이유는 
	     * 세션을 비워도 유저가 페이지를 나가서 다시 재접속하더라도 사용하던 언어가 그대로 적용이 되는지 테스트 해보려고 ..
	     * */
	     if(session != null){
	    	 session.invalidate();
	     }
	     
	     /*
	      * 다시 세션 생성.. 아까 세션을 초기화 했으니까 다시 새로운 세션을 생성하여 넘어온 language 값을 넣는다.
	      * */
	     session = request.getSession(true);
	     session.setAttribute("language", language); 
	 
	     /*
	      * 세션이 잘 생성됬는지 로그에 찍어서 테스트해보는 과정이다
	      * */
	     String lang=(String) session.getAttribute("language");
	     logger.info("lang::::   "+ lang);
		
	     
	     /*
	      * 세션에 등록된 값에 따라 localeResolver에 값에 따른 나라를 등록..
	      * 신기한게 Locale의 locale은 locale.KOREA로 한번 설정하면 계속 locale 값만 찍어도 ko_KR로 설정되어있음..
	      * 만약 locale.JAPAN로 설정하면 계속 locale 값만 찍어도 ja_JP로 설정되어있음..
	      * */
		if(lang == null) {
			logger.info("locale::::   "+ locale.toString());
			localeResolver.setLocale(request, response, locale);
		}else if(lang.equals("ko")) {
			localeResolver.setLocale(request, response, locale.KOREA);
		}else if(lang.equals("ja")) {
			localeResolver.setLocale(request, response, locale.JAPAN);
		}else if(lang.equals("en")) {
			localeResolver.setLocale(request, response, locale.ENGLISH);
		}
		
		return "myomee";
	}

}
