package com.intell.user.dao;

import java.util.List;

import com.intell.user.search.UserInfoSearch;
import com.intell.user.vo.UserInfoVo;;

public interface UserInfoDao {
   public List<UserInfoVo> selectList(UserInfoSearch search); 
   
   public int selectListCount(UserInfoSearch search);
   /*
    * 상세
    * 
    * */
   public UserInfoVo select(String userId);
   
   public void insert(UserInfoVo vo);
   
   public void update(UserInfoVo vo);
   
   public void delete(String userId);
  
}
