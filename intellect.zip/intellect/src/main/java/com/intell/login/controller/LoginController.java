package com.intell.login.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.intell.login.vo.LoginVo;
import com.intell.user.service.UserInfoService;
import com.intell.user.vo.UserInfoVo;
import com.intell.util.BaseController;

@Controller
public class LoginController extends BaseController{
     
	
	@Autowired
	private UserInfoService userInfoService;
	
	
	@RequestMapping(value="/login/loginForm.do")
     public String loginForm(
    		 @RequestParam(value="errorMessage",required=false, defaultValue="") String errorMessage,
    		 ModelMap model
    		 ) {
		model.addAttribute("errorMessage",errorMessage);
		return "/login/loginForm";
    	 
     }
     
	
	// 데이터베이스에 있는 데이터 인지 체크함 (회원 가입 되어 있는 디비인지 확인)
     @RequestMapping(value="/login/login.do")
     public ModelAndView login(HttpServletRequest request, LoginVo loginVo) throws Exception {
    	 
    	 UserInfoVo userInfo =  userInfoService.select(loginVo.getUserId());// 데이터베이스에 데이터가 있으면 객체를 생성 할 수 잇어서 
    	                                                                      // 아래의 if문에 null이 아닌 값이 된다.
    	 ModelAndView view = new ModelAndView("redirect:/userInfo/list.do");
    	 
    	 // 사용자 체크
    	 if(userInfo == null) {
    		 view.setViewName("redirect:/login/loginForm.do");
    		 view.addObject("errorMessage", "사용자가 존재하지 않습니다"); // 에러가 발생하면 loginForm 함수에 전달됨
    		 
    		 return view;
    	 }
    	 
    	// String encPw = EncryptUti.getEncMD5(loginVo.getPassword()); // 비밀번호 암호화
    	 String encPw = loginVo.getPassword(); // 
    	 //비밀번호 체크
    	 if(!userInfo.getPassword().equalsIgnoreCase(encPw)) {  // equalsIgnoreCase : 대소문자를 가려서 체크함
    		 view.setViewName("redirect:/login/loginForm.do");
    		 view.addObject("errorMessage", "비밀번호를 확인해 주세요 ");
    		 
    		 return view;
    	 }
    	 
    	 setRequestAttribute("userInfo",userInfo);
    	 setRequestAttribute("userId",loginVo.getUserId());
    
    	 return view;
     }
     
     
     @RequestMapping(value="/login/logout.do")
     public ModelAndView logout(HttpSession session) {
    	 session.invalidate();
    	 ModelAndView view = new ModelAndView("redirect:/login/loginForm.do");
    	 return view;
     }
}
