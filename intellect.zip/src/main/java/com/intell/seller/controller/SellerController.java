package com.intell.seller.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.intell.lang.search.LangSearch;
import com.intell.lang.service.LangService;
import com.intell.lang.vo.LangVo;
import com.intell.manufacturer.search.ManufacturerSearch;
import com.intell.manufacturer.service.ManufactureService;
import com.intell.manufacturer.vo.ManufactureVo;
import com.intell.util.BaseController;

@Controller
public class SellerController extends BaseController {
	
	  @Autowired
	   private ManufactureService manuService;
	  
	  @Autowired
	   private LangService langService;



	  /*
	@RequestMapping(value="/seller/inform.do")
     public ModelAndView information( ) {
		 ModelAndView view = new ModelAndView("seller/information");   
		return view;
    	 
     }
     */
	
	   @RequestMapping(value="/manufacturer/list.do")
	   public ModelAndView list(ManufacturerSearch search,LangSearch search2,
			   @RequestParam(value="man_cd", required=false) String man_cd
			   ) {
		   
		    ModelAndView view = new ModelAndView("seller/information");
		   
		   
		    List<ManufactureVo> Manvo=  manuService.selectList(search);
		    Map<String,Object> man_cd_map= new HashMap<String,Object>();
		   
		   for(int i = 0; i<Manvo.size();i++){
			  //System.out.println(Manvo.get(i).MAN_CD);
			   String MAN_CD = Manvo.get(i).MAN_CD; 
			   LangVo langvo = langService.select(MAN_CD);
			   
			   String BASE_CD_NM = langvo.getBASE_CD_NM().toString();
			  // System.out.println("단위 테스트 : "+BASE_CD_NM);
			   
			   man_cd_map.put(MAN_CD, BASE_CD_NM);
			   
		   }
		   
		  // System.out.println("MAP 데이터 확인 : "+man_cd_map.get("SY"));
		   //view.addObject("manlist",manuService.selectList(search));
		   view.addObject("man_cd_map",man_cd_map);
		   view.addObject("search", search);
		   
		 //  System.out.println("man_cd :"+man_cd);
	      return view;
	   }
	   
	   // 테스트 
	   @RequestMapping(value="/lang/list.do")
	   public ModelAndView langlist(LangSearch search) {
		   
		   ModelAndView view = new ModelAndView("seller/list");
		   view.addObject("list",langService.selectList(search));
		   view.addObject("search", search);
	      return view;
	   }
}
