package com.intell.user.search;

import com.intell.util.Search;

public class UserInfoSearch extends Search{
	 

}
