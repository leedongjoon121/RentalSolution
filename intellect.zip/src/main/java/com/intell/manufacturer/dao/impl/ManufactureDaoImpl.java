package com.intell.manufacturer.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.intell.manufacturer.dao.ManufacturerDao;
import com.intell.manufacturer.search.ManufacturerSearch;
import com.intell.manufacturer.vo.ManufactureVo;

@Repository
public class ManufactureDaoImpl implements ManufacturerDao{
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	private final static String MAPPER = "manu.ManufacturerDao.";
	
	@Override
	public ManufactureVo select(String param1) {
		// TODO Auto-generated method stub
		 return query.selectOne(MAPPER+"select",param1);
	}

	@Override
	public List<ManufactureVo> selectList(ManufacturerSearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList", search);
	}
	
	
}
