package com.intell.manufacturer.dao;

import java.util.List;

import com.intell.manufacturer.search.ManufacturerSearch;
import com.intell.manufacturer.vo.ManufactureVo;

public interface ManufacturerDao {
      public ManufactureVo select(String param1);
	  public List<ManufactureVo> selectList(ManufacturerSearch search); 
}
