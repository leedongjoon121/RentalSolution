package com.intell.manufacturer.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intell.manufacturer.dao.ManufacturerDao;
import com.intell.manufacturer.search.ManufacturerSearch;
import com.intell.manufacturer.service.ManufactureService;
import com.intell.manufacturer.vo.ManufactureVo;

@Service
public class ManufactureServiceImpl implements ManufactureService {
		@Autowired
		private ManufacturerDao manDao;
   
		@Override
		public ManufactureVo select(String param1) {
			// TODO Auto-generated method stub
			return manDao.select(param1);
		}
		
		@Override
		public List<ManufactureVo> selectList(ManufacturerSearch search) {
			// TODO Auto-generated method stub
			  return manDao.selectList(search);
		}

}
