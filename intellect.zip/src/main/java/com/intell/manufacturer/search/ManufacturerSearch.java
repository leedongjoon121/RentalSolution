package com.intell.manufacturer.search;

import com.intell.util.Search;

public class ManufacturerSearch extends Search {

}
