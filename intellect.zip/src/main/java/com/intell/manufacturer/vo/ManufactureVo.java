package com.intell.manufacturer.vo;

public class ManufactureVo {
    public String COUTRY_CD;
    public String MAN_CD;
    public String MAN_MAP_CD;
    public String SORT_ORDR;
    public String USE_YN;
    public String REG_USR_ID;
    public String REG_DT;
    public String BASE_CD;
    
    public String getCOUTRY_CD() {
		return COUTRY_CD;
	}
	public void setCOUTRY_CD(String cOUTRY_CD) {
		COUTRY_CD = cOUTRY_CD;
	}
	
    
	public String getBASE_CD() {
		return BASE_CD;
	}
	public void setBASE_CD(String bASE_CD) {
		BASE_CD = bASE_CD;
	}
	public String getCOUNTRY_CD() {
		return COUTRY_CD;
	}
	public void setCOUNTRY_CD(String cOUNTRY_CD) {
		COUTRY_CD = cOUNTRY_CD;
	}
	public String getMAN_CD() {
		return MAN_CD;
	}
	public void setMAN_CD(String mAN_CD) {
		MAN_CD = mAN_CD;
	}
	public String getMAN_MAP_CD() {
		return MAN_MAP_CD;
	}
	public void setMAN_MAP_CD(String mAN_MAP_CD) {
		MAN_MAP_CD = mAN_MAP_CD;
	}
	public String getSORT_ORDR() {
		return SORT_ORDR;
	}
	public void setSORT_ORDR(String sORT_ORDR) {
		SORT_ORDR = sORT_ORDR;
	}
	public String getUSE_YN() {
		return USE_YN;
	}
	public void setUSE_YN(String uSE_YN) {
		USE_YN = uSE_YN;
	}
	public String getREG_USR_ID() {
		return REG_USR_ID;
	}
	public void setREG_USR_ID(String rEG_USR_ID) {
		REG_USR_ID = rEG_USR_ID;
	}
	public String getREG_DT() {
		return REG_DT;
	}
	public void setREG_DT(String rEG_DT) {
		REG_DT = rEG_DT;
	}
}
