package com.intell.lang.search;

import com.intell.util.Search;

public class LangSearch extends Search{

}
