package com.intell.lang.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.intell.lang.dao.LangDao;
import com.intell.lang.search.LangSearch;
import com.intell.lang.vo.LangVo;

@Repository
public class LangDaoImpl implements LangDao{

	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	private final static String MAPPER = "lang.langDao.";
	
	public LangVo select(String param1) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"select",param1);	}

	public List<LangVo> selectList(LangSearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList", search);
	}

}
