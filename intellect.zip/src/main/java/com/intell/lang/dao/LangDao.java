package com.intell.lang.dao;

import java.util.List;

import com.intell.lang.search.LangSearch;
import com.intell.lang.vo.LangVo;

public interface LangDao {
  
	public LangVo select(String param1);
    public List<LangVo> selectList(LangSearch search);
}
