package com.intell.lang.service;

import java.util.List;

import com.intell.lang.search.LangSearch;
import com.intell.lang.vo.LangVo;

public interface LangService {
	  public LangVo select(String param1);
	  public List<LangVo> selectList(LangSearch search);
}
