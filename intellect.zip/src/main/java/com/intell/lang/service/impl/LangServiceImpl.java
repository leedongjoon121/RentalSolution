package com.intell.lang.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intell.lang.dao.LangDao;
import com.intell.lang.search.LangSearch;
import com.intell.lang.service.LangService;
import com.intell.lang.vo.LangVo;

@Service
public class LangServiceImpl implements LangService{

	@Autowired
	private LangDao langDao;
	
	@Override
	public LangVo select(String param1) {
		// TODO Auto-generated method stub
		return langDao.select(param1);
	}

	@Override
	public List<LangVo> selectList(LangSearch search) {
		// TODO Auto-generated method stub
		  return langDao.selectList(search);
	}

}
