package com.intell.lang.vo;

public class LangVo {
    public String LANG_CD;
    public String BASE_CD;
    public String BASE_CD_NM;
    public String DEFAULT_YN;
    public String USE_YN;
    public String IMG_PATH;
    public String REG_USR_ID;
    public String REG_DT;
    
	public String getLANG_CD() {
		return LANG_CD;
	}
	public void setLANG_CD(String lANG_CD) {
		LANG_CD = lANG_CD;
	}
	public String getBASE_CD() {
		return BASE_CD;
	}
	public void setBASE_CD(String bASE_CD) {
		BASE_CD = bASE_CD;
	}
	public String getBASE_CD_NM() {
		return BASE_CD_NM;
	}
	public void setBASE_CD_NM(String bASE_CD_NM) {
		BASE_CD_NM = bASE_CD_NM;
	}
	public String getDEFAULT_YN() {
		return DEFAULT_YN;
	}
	public void setDEFAULT_YN(String dEFAULT_YN) {
		DEFAULT_YN = dEFAULT_YN;
	}
	public String getUSE_YN() {
		return USE_YN;
	}
	public void setUSE_YN(String uSE_YN) {
		USE_YN = uSE_YN;
	}
	public String getIMG_PATH() {
		return IMG_PATH;
	}
	public void setIMG_PATH(String iMG_PATH) {
		IMG_PATH = iMG_PATH;
	}
	public String getREG_USR_ID() {
		return REG_USR_ID;
	}
	public void setREG_USR_ID(String rEG_USR_ID) {
		REG_USR_ID = rEG_USR_ID;
	}
	public String getREG_DT() {
		return REG_DT;
	}
	public void setREG_DT(String rEG_DT) {
		REG_DT = rEG_DT;
	}
}
